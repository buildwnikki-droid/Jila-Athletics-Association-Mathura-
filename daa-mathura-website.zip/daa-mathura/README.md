# District Athletics Association, Mathura — Website

A static website (HTML5 / CSS3 / vanilla JS) for the District Athletics Association, Mathura. No backend or database required — host on GitHub Pages, Netlify, Vercel, or any static host.

## Structure

```
/
├── index.html
├── about.html
├── leadership.html
├── athletes.html
├── events.html
├── results.html
├── news.html
├── gallery.html
├── contact.html
├── css/style.css
├── js/main.js
├── assets/images/
├── assets/news/
├── assets/icons/
└── DATA-TO-VERIFY.md   (internal only — do not publish)
```

## Adding real photographs and clippings

No photo ZIP was received when this site was generated, so every photo/clipping slot currently shows a labeled placeholder instead of an invented image. To finish the site:

1. Save the association logo as `assets/images/logo.png`.
2. Save the homepage hero photograph as `assets/images/hero-banner.jpg`.
3. Save the numbered gallery photographs into `assets/images/` using the filenames already referenced in `gallery.html` (e.g. `01_2021-11-24_event_photo.jpg`).
4. Save newspaper clippings into `assets/news/` using the filenames already referenced in `news.html` (e.g. `08_news_amrit_kumar_international.jpg`).

Once a file exists at the referenced path, it will automatically appear (the placeholder `onerror`/text fallback only shows when the file is missing).

## Content policy followed

- No invented athlete records, statistics, dates, sponsors, or officials.
- All leadership contact details are shown as supplied, flagged for verification before public launch (see `DATA-TO-VERIFY.md`).
- Missing information is labeled "Information will be updated soon" or "Date to be announced" rather than fabricated.

## Before launch

See `DATA-TO-VERIFY.md` for the checklist of items (addresses, PIN codes, photo publication permission, exact dates, official designation) that need confirmation from the association before this goes live.
