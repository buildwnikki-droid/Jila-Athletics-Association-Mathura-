# Data to Verify Before Launch

This checklist is for internal use only. Do not publish or link to this file from the website.

- [ ] President's PIN code / address (261001) — confirm accuracy
- [ ] Secretary's PIN code / address (261006) — confirm accuracy
- [ ] Treasurer's PIN code / address (281302) — confirm accuracy
- [ ] Confirm each office bearer consents to public display of their home address
- [ ] Confirm each office bearer consents to public display of their personal phone number
- [ ] Confirm each office bearer consents to public display of their personal email address
- [ ] Exact dates of each newspaper article (several gallery/news filenames imply dates — confirm these are accurate rather than assumed)
- [ ] Exact event dates for all championships/trials currently marked "to be announced"
- [ ] Exact wording of Amit Kumar's achievement (event, time, competition, qualification status) against the original clipping
- [ ] Written permission to publish all supplied photographs (they originated as social media screenshots)
- [ ] Official association logo (a placeholder logo slot is used; confirm final artwork)
- [ ] Official social media links (none included — none were supplied)
- [ ] Official registration/trials portal link, if one exists
- [ ] Official association establishment year
- [ ] Exact legal/organizational designation (e.g. registration status, affiliation with any state or national body) — the site currently avoids implying government status
